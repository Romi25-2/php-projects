<?php
require_once __DIR__ . '/includes/session.php';

require_once __DIR__ . '/includes/db.php';

//checks if usr is logged in 1
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: messages.php");
    exit();
}

$user_id = (int) $_SESSION['user_id'];

$csrf_token = $_POST['csrf_token'] ?? '';

if (
    empty($_SESSION['messages_csrf_token']) ||
    !is_string($csrf_token) ||
    !hash_equals($_SESSION['messages_csrf_token'], $csrf_token)
) {
    $_SESSION['message_errors'] = [
        "Invalid request. Please try again."
    ];

    header("Location: messages.php");
    exit();
}
// returns and sanitixe input fields
$receiver_id = filter_input(
    INPUT_POST,
    'receiver_id',
    FILTER_VALIDATE_INT
);

$message_text = is_string($_POST['message_text'] ?? null)
    ? trim($_POST['message_text'])
    : '';

$errors = [];

// validate recipient when you want to send a message to another user
if (!$receiver_id || $receiver_id === $user_id) {
    $errors[] = "Please select a valid recipient.";
}

if ($message_text === '') {
    $errors[] = "Please enter a message.";
} elseif (strlen($message_text) > 5000) {
    $errors[] = "Your message cannot exceed 5000 characters.";
}

// Confirm that the recipient exists.
if (empty($errors)) {
    $stmt = $pdo->prepare(
        "SELECT user_id FROM users WHERE user_id = ?"
    );
    $stmt->execute([$receiver_id]);

    if (!$stmt->fetch()) {
        $errors[] = "The selected user does not exist.";
    }
}

if (!empty($errors)) {
    $_SESSION['message_errors'] = $errors;

    if ($receiver_id && $receiver_id !== $user_id) {
        header("Location: messages.php?user_id=" . $receiver_id);
    } else {
        header("Location: messages.php");
    }

    exit();
}

try {
     // inseert the secure message record into the database
    $stmt = $pdo->prepare(
        "INSERT INTO messages
            (sender_id, receiver_id, message_text)
         VALUES (?, ?, ?)"
    );

    $stmt->execute([
        $user_id,
        $receiver_id,
        $message_text
    ]);

    $_SESSION['message_success'] = "Message sent successfully.";

} catch (PDOException $e) {
    $_SESSION['message_errors'] = [
        "The message could not be sent. Please try again."
    ];
}

//redirect back to the conversation thread with the recipient
header("Location: messages.php?user_id=" . $receiver_id);
exit();
?>
