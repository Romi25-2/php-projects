# Eventora

A PHP and MySQL event-management application intended to run locally with XAMPP.

## Project folders

- `includes/` - shared PHP configuration and database connection.
- `css/` - shared responsive stylesheet.
- `js/` - shared client-side JavaScript.
- `uploads/profiles/` - uploaded profile pictures.
- `database/` - SQL schema for a new installation.

Most PHP pages remain in the project root so current links and form actions keep working.

## Requirements

- XAMPP with Apache and MySQL/MariaDB.
- PHP 8.0 or newer with PDO MySQL, Fileinfo, and OpenSSL enabled.
- MySQL 8.0+ for the supplied schema collation.
- Composer if you need to reinstall PHP dependencies.

## Setup with XAMPP

1. Place this project in `C:\xampp\htdocs\EventManagmentSystem`.
2. Start Apache and MySQL from the XAMPP Control Panel.
3. Keep the project-root `composer.json` and `composer.lock`. The ZIP may include the existing `vendor/` directory; if it is missing, run `composer install` from the project root (requires Composer and internet access).
4. Open `http://localhost/phpmyadmin/`.
5. **For a fresh installation**, create a database named `eventmanagement_db`, select it, and import `database/migrations/eventManagment.sql`. This is the only SQL file currently in the migrations folder and creates the full application schema.
6. **For an existing database**, back it up before making changes. This project folder no longer includes incremental upgrade scripts. Do not import the full schema over a database containing data; compare its schema with `eventManagment.sql` and prepare/apply the required alterations separately, or use a fresh database.
7. Create a dedicated application database account with a strong, unique password. In phpMyAdmin's SQL tab, as a database administrator, replace the placeholder below with your own password and run:
   ```sql
   CREATE USER 'event_app'@'localhost'
       IDENTIFIED BY 'REPLACE_WITH_A_STRONG_UNIQUE_PASSWORD';
   ```
   Then grant it only the permissions required by the application:
   ```sql
   GRANT SELECT, INSERT, UPDATE, DELETE ON eventmanagement_db.* TO 'event_app'@'localhost';
   ```
   Use an administrator account separately to import the schema. Do not put the real password in project files or the ZIP.
8. Configure Apache environment variables outside the project folder. In `C:\xampp\apache\conf\extra\httpd-xampp.conf`, add these lines inside the existing `<IfModule env_module>` section, substituting the password for the account created above:
   ```apache
   SetEnv EVENT_DB_HOST "localhost"
   SetEnv EVENT_DB_NAME "eventmanagement_db"
   SetEnv EVENT_DB_USER "event_app"
   SetEnv EVENT_DB_PASSWORD "YOUR_STRONG_UNIQUE_PASSWORD"
   SetEnv APP_ENV "development"
   ```
   `APP_ENV=development` enables the reset link only for localhost requests; use `APP_ENV=production` with SMTP configured for a deployed site. Keep the actual database password private. Run `C:\xampp\apache\bin\httpd.exe -t` and confirm it reports `Syntax OK`.
9. Restart Apache in the XAMPP Control Panel.
10. Open `http://localhost/EventManagmentSystem/`. Database-backed pages require the database and environment settings above.

The database connection defaults to `localhost` and `eventmanagement_db`. `EVENT_DB_USER` and `EVENT_DB_PASSWORD` are required and have no source-code fallback; the app reports a configuration error if either is missing. Do not publish database credentials or use a database administrator account for normal application access.

Apache must allow `.htaccess` overrides for this folder. The supplied XAMPP configuration does; the project disables directory listings and blocks direct web access to `database/`, `includes/`, and `vendor/`.

## Session and HTTPS security

The application uses strict PHP sessions with `HttpOnly` and `SameSite=Lax` cookies, sets the `Secure` cookie flag when PHP detects HTTPS, and expires sessions after 30 minutes of inactivity. Logout uses a CSRF-protected POST form. The application does not itself redirect HTTP to HTTPS: configure Apache/the hosting proxy to do so and report HTTPS correctly to PHP. Local HTTP on XAMPP does not set the `Secure` cookie flag.

After a successful password reset, the session used to submit the reset is invalidated, and the session version is incremented to revoke all other active logins on their next request. For production, also configure HTTPS-only access and deliver reset links by email rather than displaying them locally.

## Password reset email

Set `APP_ENV=production`, `APP_BASE_URL` to the application's HTTPS base URL (without a trailing slash), and configure `SMTP_HOST`, `SMTP_PORT`, `SMTP_USERNAME`, `SMTP_PASSWORD`, `SMTP_ENCRYPTION` (`tls` or `ssl`), `MAIL_FROM_ADDRESS`, and `MAIL_FROM_NAME`. Install PHP dependencies with `composer install`; production reset links are only sent through the configured authenticated SMTP service, and are never displayed in the web page. If delivery fails, the reset token is invalidated.

For local testing only, set `APP_ENV=development` and access the site from `127.0.0.1` or `::1` to display the reset link in the page. Requests are limited to 5 per IP and 3 per email address per 15-minute window. If the application is behind a reverse proxy, configure the network so PHP's `REMOTE_ADDR` is the actual client address; do not trust arbitrary forwarded headers.

## Main pages

- `register.php` - create an account.
- `login.php` - sign in.
- `dashboard.php` - upcoming events and navigation.
- `events.php` - create, edit, delete, and browse events.
- `profile.php` - view or update a profile.
- `search.php` - search users and events.
- `messages.php` - private messages.
- `forgotPass.php` - request a password reset link for local development.

## Key code walkthrough

Use this section as a guide to understanding and explaining the main implementation:

- **Database connection - `includes/db.php`:** reads the database host/name and required username/password from environment variables, then creates a PDO connection. PDO exceptions and native prepared statements are enabled. For a signed-in user, it also compares the session's saved `session_version` with the database value; a mismatch invalidates that login.
- **Session security - `includes/session.php`:** starts the shared PHP session with strict mode and cookie protections (`HttpOnly`, `SameSite=Lax`, and `Secure` when HTTPS is detected). It clears sessions after 30 minutes without activity and creates the shared CSRF token.
- **Registration - `registrationProcess.php`:** validates form fields and optional profile images, hashes passwords with `password_hash()`, and inserts user data with a prepared statement. Image uploads are limited to JPEG, PNG, or WEBP, checked by file content and size, and saved with a generated filename.
- **Login - `loginProcess.php`:** looks up the account by email using a prepared statement, checks the stored password hash with `password_verify()`, regenerates the session ID after successful authentication, and stores the user's ID and session version in the session.
- **Event actions - `events.php` and `eventProcess.php`:** `events.php` displays events and provides forms; `eventProcess.php` validates submitted actions and performs create, update, or delete operations. Ownership checks ensure users can only change their own events.
- **Private messages - `messages.php` and `messageProcess.php`:** the conversation query selects only messages between the signed-in user and the selected contact. Messages are ordered by timestamp and ID; opening a thread marks only messages received by the signed-in user as read. Unread counts are filtered by the current recipient.
- **Search - `search.php`, `searchProcess.php`, `liveSearch.php`, and `js/search.js`:** the normal form submits a search to the server; JavaScript also requests live results after the user types. The browser cancels outdated requests and creates result elements using text content, while the PHP endpoints validate input and use prepared SQL statements.
- **Password reset - `forgotPass.php`, `includes/password_reset_mailer.php`, and `reset_password.php`:** the app generates a random reset token but stores only its SHA-256 hash. The token expires after 30 minutes and is cleared after use. Development displays the reset link only for localhost requests; other requests use configured authenticated SMTP. Successful resets increment `session_version` so other signed-in sessions are invalidated on their next request.
- **Output escaping and SQL safety:** PHP templates use `htmlspecialchars()` when displaying user-supplied text, and database queries that include user input use prepared statements. These protections address different risks: escaping protects HTML output, while prepared statements separate SQL code from query values.

## Notes

- Production password reset links are sent through the configured SMTP service; the development link is restricted to localhost requests.
- Profile uploads accept JPG, PNG, and WEBP images up to 2 MB.
- Server-side validation remains authoritative; JavaScript validation is for convenience only.
- The application currently expects `users.pricture_picture` and `users.create_at`, matching the schema inspected during development. Update the application queries if your schema uses different names.
- `database/migrations/eventManagment.sql` is the full schema to import for a fresh database. No incremental migration scripts are currently included for existing databases.
