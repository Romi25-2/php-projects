<?php
require_once __DIR__ . '/includes/session.php';

// if the user is a;ready logged in, the browser opens the dashboard
if(isset($_SESSION['user_id'])){
    header('Location: dashboard.php');
    exit;
}
// get messages from the login process file

$errors = $_SESSION['LoginErrors'] ?? [];
$success = $_SESSION['success'] ?? '';

// clear the error or success message from login process 
unset($_SESSION['LoginErrors'], $_SESSION['success']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Log In | Eventora</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="js/client.js" defer></script>
</head>
<body>
<main class="page-wrap">
<h1>Login to your Account</h1>
<!-- displayy success flsh message -->
<?php if($success !== ''): ?>
    <p class="flash--ok">
        <?=  htmlspecialchars($success, ENT_QUOTES, 'UTF-8') ?>
    </p>
<?php endif; ?>

<!-- display and login error message  -->
<?php  foreach ($errors as $error): ?> 
    <p class="flash--err">
       <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>  <!-- ENT_QUOTES preventing attackers from breaking out of attribute strings -->
    </p>
    <?php endforeach; ?>


<form action="loginProcess.php" method="post">

<label>Email: </label>
<input type="email" name="email" maxlength="150" id="account-email" required><br><br>

<label>Pasword</label>
<input type="password" name="password" id="account-password" required><br><br>

<button type="submit">Login</button>

</form>
<p><a class="button-link" href="forgotPass.php">Forgot your password?</a></p>

<p>Don't have an account? <a href="register.php">Registere here </a></p>

</main>

</body>
</html>