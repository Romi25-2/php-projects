<?php
require_once __DIR__ . '/includes/session.php';

require_once __DIR__ . '/includes/db.php';

// Only logged in users can search
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    header('Location: search.php');
    exit;
}

$searchType = is_string($_GET['search_type'] ?? null)
    ? $_GET['search_type']
    : '';
$query = is_string($_GET['query'] ?? null)
    ? trim($_GET['query'])
    : '';

$errors = [];

// Validate search type
if (!in_array($searchType, ['events', 'users'], true)) {
    $errors[] = "Invalid search category.";
}

// Validate search term
if ($query === '') {
    $errors[] = "Please enter a search term.";
} elseif (strlen($query) > 100) {
    $errors[] = "Your search must not exceed 100 characters.";
}

if (!empty($errors)) {
    $_SESSION['search_error'] = implode(' ', $errors);
    $_SESSION['search_type'] = in_array($searchType, ['events', 'users'], true)
        ? $searchType : 'events';
    $_SESSION['search_query'] = $query;

    header('Location: search.php');
    exit;
}

try {
    // Add wildcards to search for partial dataabse matches
    $searchTerm = '%' . $query . '%';

    if ($searchType === 'events') {

        // Search event titles and locations, putting upcoming event firsts 
        $stmt = $pdo->prepare(
            "SELECT events.event_id,
                    events.title,
                    events.description,
                    events.event_date,
                    events.location,
                    users.full_name AS organiser
             FROM events
             INNER JOIN users ON events.user_id = users.user_id
             WHERE events.title LIKE ?
                OR events.location LIKE ?
             ORDER BY
                CASE WHEN events.event_date >= NOW() THEN 0 ELSE 1 END,
                events.event_date ASC
             LIMIT 50"
        );

        $stmt->execute([$searchTerm, $searchTerm]);

    } else {

        // Search users by name from a-z 
        $stmt = $pdo->prepare(
            "SELECT user_id,
                    full_name,
                    pricture_picture AS profile_picture,
                    create_at AS created_at
             FROM users
             WHERE full_name LIKE ?
             ORDER BY full_name ASC
             LIMIT 50"
        );

        $stmt->execute([$searchTerm]);
    }

    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Send results back to the search page
    $_SESSION['search_type'] = $searchType;
    $_SESSION['search_query'] = $query;
    $_SESSION['search_results'] = $results;

} catch (PDOException $e) {
    error_log($e->getMessage());

    $_SESSION['search_type'] = $searchType;
    $_SESSION['search_query'] = $query;
    $_SESSION['search_error'] = "Search failed. Please try again.";
}

// redirect back to display results on the search view page
header('Location: search.php');
exit;
