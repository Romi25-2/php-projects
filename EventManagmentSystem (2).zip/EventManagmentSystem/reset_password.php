<?php
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/includes/db.php';

$token = $_POST['token'] ?? $_GET['token'] ?? '';
$errors = [];
$success = '';

//validate token format
if (!is_string($token) || !preg_match('/\A[a-f0-9]{64}\z/i', $token)) {
    $token = '';
    $errors[] = 'This password reset link is invalid or has expired.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $token !== '') {
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    //validate password constraints
    if (!is_string($password) || strlen($password) < 8) {
        $errors[] = 'Password must contain at least 8 characters.';
    } elseif (strlen($password) > 72) {
        $errors[] = 'Password must not exceed 72 bytes.';
    }
//confirm password match
    if (!is_string($confirmPassword) || $password !== $confirmPassword) {
        $errors[] = 'Passwords do not match.';
    }

    if (empty($errors)) {
        try {
            $tokenHash = hash('sha256', $token);
            //check if token exist
            $stmt = $pdo->prepare(
                'SELECT user_id
                 FROM users
                 WHERE reset_token_hash = ?
                 AND reset_expires_at > NOW()'
            );
            $stmt->execute([$tokenHash]);
            $userId = $stmt->fetchColumn();

            if (!$userId) {
                $errors[] = 'This password reset link is invalid or has expired.';
            } else {
                // update password and invalidate the reset token instantly
                $stmt = $pdo->prepare(
                    'UPDATE users
                     SET password = ?,
                         reset_token_hash = NULL,
                         reset_expires_at = NULL,
                         session_version = session_version + 1
                     WHERE user_id = ?
                     AND reset_token_hash = ?
                     AND reset_expires_at > NOW()'
                );
                $stmt->execute([
                    password_hash($password, PASSWORD_DEFAULT),
                    $userId,
                    $tokenHash
                ]);

                if ($stmt->rowCount() !== 1) {
                    $errors[] = 'This password reset link is invalid or has expired.';
                } else {
                    $success = 'Your password has been reset. You can now log in.';
                    $token = '';
                    $_SESSION = [];
                    session_regenerate_id(true);
                }
            }
        } catch (PDOException $e) {
            error_log($e->getMessage());
            $errors[] = 'Unable to reset your password right now. Please try again.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password | Eventora</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="js/client.js" defer></script>
</head>
<body>
    <h1>Reset Password</h1>

    <!-- display validation or token errors -->
    <?php foreach ($errors as $error): ?>
        <p class="flash--err"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
    <?php endforeach; ?>
    <!-- display message and login link  -->
    <?php if ($success !== ''): ?>
        <p class="flash--ok"><?= htmlspecialchars($success, ENT_QUOTES, 'UTF-8') ?></p>
        <p><a href="login.php">Return to Login</a></p>
    <?php elseif ($token !== ''): ?>
        <form action="reset_password.php" method="POST">
            <input
                type="hidden"
                name="token"
                value="<?= htmlspecialchars($token, ENT_QUOTES, 'UTF-8') ?>"
            >

            <label for="new-password">New password:</label>
            <input type="password" name="password" id="new-password" maxlength="72" required>

            <label for="password-confirmation">Confirm new password:</label>
            <input type="password" name="confirm_password" id="password-confirmation" maxlength="72" required>

            <button type="submit">Reset Password</button>
        </form>
    <?php endif; ?>
</body>
</html>
