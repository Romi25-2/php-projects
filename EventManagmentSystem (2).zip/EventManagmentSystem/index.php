<?php
require_once __DIR__ . '/includes/db.php';
// verifies server availability and database connectivity
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eventora | Event Management</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    
        <h1>Eventora</h1>
        <p>Your PHP app is running.</p>

        <?php
            if (isset($pdo)){
            echo"<p>Database has connected successfully.</p>";
            }
                
        ?>
</body>
</html>