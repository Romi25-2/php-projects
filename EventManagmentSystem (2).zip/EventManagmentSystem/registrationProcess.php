<?php
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/includes/db.php';

$errors = [];

if ($_SERVER['REQUEST_METHOD'] ==='POST'){
    $fullName = is_string($_POST['fullName'] ?? null)
        ? trim($_POST['fullName']): '';
    $email = is_string($_POST['email'] ?? null)
        ? trim($_POST['email']): '';
    $password = is_string($_POST['password'] ?? null)
        ? $_POST['password']: '';
    $confirmpass = is_string($_POST['confirmPass'] ?? null)
        ? $_POST['confirmPass']: '';

        //validate full name, email,password,confirm password and picture
    if ($fullName === '' || strlen($fullName) > 255) {
        $errors[] = 'Enter a name of no more than 255 characters.';
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 150) {
        $errors[] = 'Enter a valid email address.';
    }
    if (strlen($password) < 8) {
        $errors[] = 'Password must contain at least 8 characters.';
    } elseif (strlen($password) > 72) {
        $errors[] = 'Password must not exceed 72 bytes.';
    }
    if ($password !== $confirmpass) {
        $errors[] = 'Passwords do not match.';
    }

    $allowedTypes = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp'
    ];
    $pictureExtension = null;
    $picture = null;
    if (array_key_exists('profile_picture', $_FILES)) {
        $picture = $_FILES['profile_picture'];
        if (!is_array($picture) || !isset($picture['error'])) {
            $errors[] = 'The profile picture could not be uploaded.';
        } elseif ($picture['error'] === UPLOAD_ERR_NO_FILE) {
            $picture = null;
        } elseif (
            $picture['error'] !== UPLOAD_ERR_OK ||
            !isset($picture['tmp_name'], $picture['size']) ||
            !is_string($picture['tmp_name']) ||
            !is_numeric($picture['size']) ||
            !is_uploaded_file($picture['tmp_name'])
        ) {
            $errors[] = 'The profile picture could not be uploaded.';
        } elseif ((int) $picture['size'] > 2 * 1024 * 1024) {
            $errors[] = 'The profile picture must not exceed 2 MB.';
        } else {
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mimeType = $finfo->file($picture['tmp_name']);
            $pictureExtension = is_string($mimeType)
                ? ($allowedTypes[$mimeType] ?? null)
                : null;

            if (
                $pictureExtension === null ||
                @getimagesize($picture['tmp_name']) === false
            ) {
                $errors[] = 'Choose a valid JPG, PNG or WEBP image.';
            }
        }
    }

    if (empty($errors)) {
        try { // cehck if email already exists 
            $checkEmail = $pdo->prepare(
                'SELECT COUNT(*) FROM users WHERE email = ?'
            );
            $checkEmail->execute([$email]);

            if ((int) $checkEmail->fetchColumn() > 0) {
                $errors[] = 'This email is already registered.';
            } else {
                $pictureName = null;
                if ($pictureExtension !== null && is_array($picture)) {
                    $uploadDirectory = __DIR__ . '/uploads/profiles/';
                    if (
                        !is_dir($uploadDirectory) &&
                        !mkdir($uploadDirectory, 0755, true) &&
                        !is_dir($uploadDirectory)
                    ) {
                        throw new RuntimeException('The upload folder could not be created.');
                    }

                    $pictureName = bin2hex(random_bytes(16)) . '.' . $pictureExtension;
                    $picturePath = $uploadDirectory . $pictureName;

                    if (!move_uploaded_file($picture['tmp_name'], $picturePath)) {
                        throw new RuntimeException('The profile picture could not be saved.');
                    }
                }

                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

                //insert new user into the database
                $stmt = $pdo->prepare(
                    'INSERT INTO users (full_name, email, password, pricture_picture)
                    VALUES (?, ?, ?, ?)'
                );
                $stmt->execute([$fullName, $email, $hashedPassword, $pictureName]);

                $_SESSION['success'] = 'Registration successful!';
                header('Location: register.php');
                exit;
            }
        } catch (PDOException $e) {
            if (isset($picturePath) && is_file($picturePath)) {
                unlink($picturePath);
            }
            error_log($e->getMessage());
            $errors[] = $e->getCode() === '23000'
                ? 'This email is already registered.'
                : 'Registration failed. Please try again.';
        } catch (Throwable $e) {
            if (isset($picturePath) && is_file($picturePath)) {
                unlink($picturePath);
            }
            error_log($e->getMessage());
            $errors[] = 'Registration failed. Please try again.';
        }
    }

    //saves old input and error in session upon falure
    $_SESSION['errors'] = $errors;
    $_SESSION['old'] = [
        'fullName' => $fullName,
        'email' => $email
    ];
    header('Location: register.php');
    exit;
} else {
    header('Location: register.php');
    exit;
}
?>
