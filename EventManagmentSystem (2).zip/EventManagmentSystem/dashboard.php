<?php
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/includes/db.php';

// redircet users to the login page
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// great user with the name they login ith 
$fullName = $_SESSION['full_name'] ?? '';
$userId = (int) $_SESSION['user_id'];

try{
// get upcoming events with a limit of 5, dashboard should not pull the whole table
    $stmt = $pdo->prepare(
        "SELECT events.event_id,
        events.title,
        events.description,
        events.event_date,
        events.location,
        users.full_name AS organiser
        FROM events
        INNER JOIN users ON events.user_id = users.user_id
        WHERE events.event_date >= NOW()
        ORDER BY events.event_date ASC
        LIMIT 5 "
    );
    $stmt->execute();
    $upcomingEvents = $stmt->fetchAll(PDO::FETCH_ASSOC);

}catch (PDOException $e){
    //the dahsboard should still work even if this fails
    //show a friendly message pn the page
    error_log($e->getMessage());
    $upcomingEvents = [];
    $eventError = "Unable to load upcoming events.";
}
// Count unread messages received by the logged-in user.display besides MESSAGES
$unreadMessages = 0;

try {
    $stmt = $pdo->prepare(
        'SELECT COUNT(*)
        FROM messages
        WHERE receiver_id = :user_id
          AND is_read = FALSE'
    );

    $stmt->execute(['user_id' => $userId]);
    $unreadMessages = (int) $stmt->fetchColumn();
} catch (PDOException $e) {
    error_log($e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | Eventora</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header class="site-header">
        <div class="header-left">
            <a class="brand" href="dashboard.php" aria-label="Eventora home">
                <span class="brand-name">Eventora</span>
            </a>
            <nav aria-label="Main navigation">
                <ul class="header-nav-list">
                    <li><a href="dashboard.php" aria-current="page">Dashboard</a></li>
                    <li><a href="events.php#create-event">Create Event</a></li>
                    <li><a href="search.php">Search</a></li>
                    <li>
                        <a href="messages.php">
                            Messages<?php if ($unreadMessages > 0): ?>
                                (<?= $unreadMessages ?>)
                            <?php endif; ?>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
        <div class="header-actions">
            <a class="header-user" href="profile.php">
                <?= htmlspecialchars($fullName, ENT_QUOTES, 'UTF-8') ?>
            </a>
            <form action="logoutProcess.php" method="post">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">
                <button class="header-logout" type="submit">Logout</button>
            </form>
        </div>
    </header>
    <main class="dashboard-layout">
        <section class="dashboard-card dashboard-intro">
            <h2>Welcome, <?= htmlspecialchars($fullName, ENT_QUOTES, 'UTF-8') ?>!</h2>
            <p>Bring people together. Create an event, find something to attend, or connect with other members.</p>

            <div class="dashboard-actions">
                <a class="button-link" href="events.php#create-event">Create Event</a>
                <a class="button-link" href="search.php">Search</a>
                <a class="button-link" href="messages.php">Messages</a>
            </div>

            <hr>

            <h3>Your Next Event</h3>
            <?php if (isset($eventError)): ?>
                <p class="flash--err"><?= htmlspecialchars($eventError, ENT_QUOTES, 'UTF-8') ?></p>
            <?php elseif (!empty($upcomingEvents)): ?>
                <p>
                    <?= htmlspecialchars($upcomingEvents[0]['title'], ENT_QUOTES, 'UTF-8') ?>
                    &mdash;
                    <?= htmlspecialchars(date('d M Y, H:i', strtotime($upcomingEvents[0]['event_date'])), ENT_QUOTES, 'UTF-8') ?>
                    at <?= htmlspecialchars($upcomingEvents[0]['location'], ENT_QUOTES, 'UTF-8') ?>
                </p>
            <?php else: ?>
                <p>No upcoming events are available right now.</p>
            <?php endif; ?>
        </section>

        <section class="dashboard-card dashboard-upcoming" aria-labelledby="upcoming-events-heading">
            <h2 id="upcoming-events-heading">Upcoming Events</h2>
            <?php if (isset($eventError)): ?>
                <p class="flash--err"><?= htmlspecialchars($eventError, ENT_QUOTES, 'UTF-8') ?></p>
            <?php elseif (!empty($upcomingEvents)): ?>
                <ul class="upcoming-event-list">
                    <?php foreach ($upcomingEvents as $event): ?>
                        <li>
                            <a href="events.php">
                                <?= htmlspecialchars($event['title'], ENT_QUOTES, 'UTF-8') ?>
                            </a>
                            <span>
                                <?= htmlspecialchars(date('d M Y, H:i', strtotime($event['event_date'])), ENT_QUOTES, 'UTF-8') ?>
                                &middot; <?= htmlspecialchars($event['location'], ENT_QUOTES, 'UTF-8') ?>
                            </span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p>No upcoming events are available. Create one to get started.</p>
            <?php endif; ?>
        </section>
    </main>

       <footer>
        <p>&copy; <?= date('Y') ?> Eventora</p>
       </footer>

</body>
</html>