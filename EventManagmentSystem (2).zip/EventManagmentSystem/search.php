<?php
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/includes/db.php';

// Only logged in users can search
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$fullName = $_SESSION['full_name'] ?? '';
$searchType = $_SESSION['search_type'] ?? 'events';
$searchQuery = $_SESSION['search_query'] ?? '';
$results = $_SESSION['search_results'] ?? [];
$error = $_SESSION['search_error'] ?? '';

unset(
    $_SESSION['search_type'],
    $_SESSION['search_query'],
    $_SESSION['search_results'],
    $_SESSION['search_error']
);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Search | Eventora</title>

    <link rel="stylesheet" href="css/style.css">
    <script src="js/client.js" defer></script>
    <script src="js/search.js" defer></script>
</head>
<body>

<header class="site-header">
    <div class="header-left">
        <a class="brand" href="dashboard.php" aria-label="Eventora home">
            <span class="brand-name">Eventora</span>
        </a>
        <nav aria-label="Main navigation">
            <ul class="header-nav-list">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="events.php#create-event">Create Event</a></li>
                <li><a href="search.php" aria-current="page">Search</a></li>
                <li><a href="messages.php">Messages</a></li>
            </ul>
        </nav>
    </div>
    <div class="header-actions">
        <a class="header-user" href="profile.php">
            <?= htmlspecialchars($fullName, ENT_QUOTES, 'UTF-8') ?>
        </a>
        <form action="logoutProcess.php" method="post">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">
            <button class="header-logout" type="submit">Logout</button>
        </form>
    </div>
</header>

<main>
    <h2>Search</h2>
<!-- Search form -->
    <form action="searchProcess.php" method="GET">

        <label for="search-category">Search for</label>
        <select id="search-category" name="search_type">
            <option value="events"
                <?= $searchType === 'events' ? 'selected' : '' ?>>
                Events
            </option>

            <option value="users"
                <?= $searchType === 'users' ? 'selected' : '' ?>>
                Users
            </option>
        </select>

        <label for="search-query">Search term</label>
        <input
            type="search"
            id="search-query"
            name="query"
            maxlength="100"
            value="<?= htmlspecialchars($searchQuery, ENT_QUOTES, 'UTF-8') ?>"
            placeholder="Enter an event title, location or name"
            required
        >

        <button type="submit">Search</button>
    </form>
    <!-- //live search containers for js  -->
    <p id="live-search-status" role="status" aria-live="polite"></p>
    <section id="live-search-results" aria-live="polite"></section>

    <!-- //display search   -->
    <?php if ($error !== ''): ?>
        <p class="flash--err">
            <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
        </p>
    <?php endif; ?>

    <!-- //display from submitted search reults  -->
    <?php if ($searchQuery !== '' && $error === ''): ?>
        <section class="search-results">
            <h2>
                Results for "<?= htmlspecialchars($searchQuery, ENT_QUOTES, 'UTF-8') ?>"
            </h2>
            <?php if (empty($results)): ?>
                <p>No results found. Try a different search term.</p>
            <?php else: ?>
                <?php foreach ($results as $result): ?>
                    <?php if ($searchType === 'events'): ?>

                <article class="event-card">
                    <h3>
                    <?= htmlspecialchars($result['title'], ENT_QUOTES, 'UTF-8') ?>
                    </h3>
                    <p><strong>Date:</strong>
                    <?= htmlspecialchars(date('d M Y, H:i', strtotime($result['event_date'])),ENT_QUOTES, 'UTF-8'
                    ) ?></p>
                
                    <p><strong>Location:</strong>  <?= htmlspecialchars($result['location'], ENT_QUOTES, 'UTF-8') ?>  
                            </p>
                     <p>
                                <strong>Organiser:</strong><?= htmlspecialchars($result['organiser'], ENT_QUOTES, 'UTF-8') ?>
                                
                            </p>

                      <p>
                             <?= nl2br(htmlspecialchars($result['description'], ENT_QUOTES, 'UTF-8')) ?>
                    </p>

                        </article>

                    <?php else: ?>

                        <article class="user-card">
                            <h3>
                                <?= htmlspecialchars($result['full_name'], ENT_QUOTES, 'UTF-8') ?>
                            </h3>

                            <?php if (!empty($result['profile_picture'])): ?>
                                <img src="uploads/profiles/<?= rawurlencode(basename($result['profile_picture'])) ?>"
                                    alt="Profile picture"
                                    width="80"
                                    height="80"
                                    style="object-fit: cover; border-radius: 50%;"
                                >
                            <?php endif; ?>

                            <p>
                                Joined on:
                                <?= htmlspecialchars(
                                    date('d M Y', strtotime($result['created_at'])),
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>
                            </p>

                            <a href="profile.php?id=<?= (int) $result['user_id'] ?>">
                                View Profile
                            </a>
                        </article>

                    <?php endif; ?>

                <?php endforeach; ?>

            <?php endif; ?>
        </section>

    <?php endif; ?>

</main>

<footer>
    <p>&copy; <?= date('Y') ?> Eventora</p>
</footer>

</body>
</html>
