<?php
require_once __DIR__ . '/includes/session.php';

require_once __DIR__ . '/includes/db.php';


if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$fullName = $_SESSION['full_name'] ?? '';

if (empty($_SESSION['messages_csrf_token'])) {
    $_SESSION['messages_csrf_token'] = bin2hex(random_bytes(32));
}

$csrf_token = $_SESSION['messages_csrf_token'];

$users = [];
$messages = [];
$selected_user = null;
$errors = [];
$success = '';

// load conversation history if a specific user is selected 
if (isset($_SESSION['message_errors'])) {
    $errors = $_SESSION['message_errors'];
    unset($_SESSION['message_errors']);
}

if (isset($_SESSION['message_success'])) {
    $success = $_SESSION['message_success'];
    unset($_SESSION['message_success']);
}

// Get users who can receive messages.
$stmt = $pdo->prepare(
    "SELECT user_id, full_name
     FROM users
     WHERE user_id != ?
     ORDER BY full_name ASC"
);
$stmt->execute([$user_id]);
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get the selected conversation from sender and recipient
if (isset($_GET['user_id']) && filter_var($_GET['user_id'], FILTER_VALIDATE_INT)) {
    $selected_id = (int) $_GET['user_id'];

    if ($selected_id !== $user_id) {
        $stmt = $pdo->prepare(
            "SELECT user_id, full_name
             FROM users
             WHERE user_id = ?"
        );
        $stmt->execute([$selected_id]);
        $selected_user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($selected_user) {
            //load messages of logged in user and the selected contact 
            $stmt = $pdo->prepare(
                "SELECT m.*, sender.full_name AS sender_name
                 FROM messages m
                 INNER JOIN users sender
                    ON m.sender_id = sender.user_id
                 WHERE
                    (m.sender_id = ? AND m.receiver_id = ?)
                    OR
                    (m.sender_id = ? AND m.receiver_id = ?)
                 ORDER BY m.sent_at ASC, m.message_id ASC"
            );

            $stmt->execute([
                $user_id,
                $selected_id,
                $selected_id,
                $user_id
            ]);

            $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // mark the messages ones a user has recieved as read
            $stmt = $pdo->prepare(
                "UPDATE messages
                 SET is_read = TRUE
                 WHERE sender_id = ?
                 AND receiver_id = ?"
            );
            $stmt->execute([$selected_id, $user_id]);
        }
    }
}

// get the current users chat history participants.
$stmt = $pdo->prepare(
    "SELECT DISTINCT
        u.user_id,
        u.full_name
     FROM users u
     INNER JOIN messages m
        ON (
            m.sender_id = u.user_id
            AND m.receiver_id = ?
        )
        OR (
            m.receiver_id = u.user_id
            AND m.sender_id = ?
        )
     WHERE u.user_id != ?
     ORDER BY u.full_name ASC"
);

$stmt->execute([$user_id, $user_id, $user_id]);
$conversations = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Count unread messages received by the logged-in user.
$stmt = $pdo->prepare(
    "SELECT COUNT(*)
     FROM messages
     WHERE receiver_id = ?
     AND is_read = FALSE"
);
$stmt->execute([$user_id]);
$unread_messages = $stmt->fetchColumn();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Private Messages | Eventora</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="js/client.js" defer></script>
</head>
<body>

<header class="site-header">
    <div class="header-left">
        <a class="brand" href="dashboard.php" aria-label="Eventora home">
            <span class="brand-name">Eventora</span>
        </a>
        <nav aria-label="Main navigation">
            <ul class="header-nav-list">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="events.php#create-event">Create Event</a></li>
                <li><a href="search.php">Search</a></li>
                <li>
                    <a href="messages.php" aria-current="page">
                        Messages<?php if ($unread_messages > 0): ?>
                            (<?= (int) $unread_messages ?>)
                        <?php endif; ?>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
    <div class="header-actions">
        <a class="header-user" href="profile.php">
            <?= htmlspecialchars($fullName, ENT_QUOTES, 'UTF-8') ?>
        </a>
        <form action="logoutProcess.php" method="post">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">
            <button class="header-logout" type="submit">Logout</button>
        </form>
    </div>
</header>

<div class="page-wrap">
    <h1>Private Messages</h1>
    <?php if ($success !== ''): ?>
        <p class="flash--ok">
            <?= htmlspecialchars($success, ENT_QUOTES, 'UTF-8') ?>
        </p>
    <?php endif; ?>

    <?php foreach ($errors as $error): ?>
        <p class="flash--err">
            <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
        </p>
    <?php endforeach; ?>

    <h2>Start a Conversation</h2>
        <!-- selects user and open converstation thread -->
    <form action="messages.php" method="GET">
        <label for="conversation-user">Choose a user:</label>

        <select name="user_id" id="conversation-user" required>
            <option value="">Select a user</option>

            <?php foreach ($users as $user): ?>
                <option
                    value="<?= (int) $user['user_id'] ?>"
                    <?= (
                        $selected_user &&
                        (int) $selected_user['user_id'] === (int) $user['user_id']
                    ) ? 'selected' : '' ?>
                >
                    <?= htmlspecialchars($user['full_name'], ENT_QUOTES, 'UTF-8') ?>
                </option>
            <?php endforeach; ?>
        </select>

        <button type="submit">Open Conversation</button>
    </form>
<!-- conversation section when active -->
    <?php if ($selected_user): ?>
        <hr>

        <h2>
            Conversation with
            <?= htmlspecialchars($selected_user['full_name'], ENT_QUOTES, 'UTF-8') ?>
        </h2>

        <div class="msg-list">
            <?php if (empty($messages)): ?>
                <p>No messages yet. Start the conversation below.</p>
            <?php else: ?>
                <?php foreach ($messages as $message): ?>
                    <?php $isOutgoing = (int) $message['sender_id'] === (int) $user_id; ?>
                    <div class="msg <?= $isOutgoing ? 'msg--outgoing' : 'msg--incoming' ?>">
                        <strong>
                            <?= htmlspecialchars($message['sender_name'], ENT_QUOTES, 'UTF-8') ?>
                        </strong>

                        <p>
                            <?= nl2br(htmlspecialchars($message['message_text'], ENT_QUOTES, 'UTF-8')) ?>
                        </p>

                        <small>
                            <?= htmlspecialchars($message['sent_at'], ENT_QUOTES, 'UTF-8') ?>
                        </small>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <!-- //form thats sends new message in the current thread -->
        <form action="messageProcess.php" method="POST">
            <input type="hidden" name="csrf_token"
                   value="<?= htmlspecialchars($csrf_token, ENT_QUOTES, 'UTF-8') ?>">

            <input type="hidden" name="receiver_id"
                   value="<?= (int) $selected_user['user_id'] ?>">

            <label for="message-body">Your Message:</label>

            <textarea name="message_text"id="message-body"rows="4"maxlength="5000"required></textarea>

            <button type="submit" name="send_message">
                Send Message
            </button>
        </form>
    <?php endif; ?>
</div>

</body>
</html>
