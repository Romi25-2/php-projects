<?php
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/includes/db.php';

//strcitly accepts posts from the login.php
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: login.php');
    exit;
}

//return trimmed input field safely 
 $email = is_string($_POST['email'] ?? null)
    ? trim($_POST['email'])
    : '';
 $password = is_string($_POST['password'] ?? null)
    ? $_POST['password']
    : '';

if ($email === '' || !is_string($password) || $password === '') {
    $_SESSION['LoginErrors'] = [
        "Please enter your email address and password."
    ];
    header('Location: login.php');
    exit;
}

try {
    //fetches user account detailes by email
    $stmt = $pdo->prepare(
        "SELECT user_id, full_name, email, password, session_version
         FROM users
         WHERE email = ?"
    );
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    //checks is user password matches the secure hashed one
    if ($user && password_verify($password, $user['password'])) {
        session_regenerate_id(true);
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['auth_session_version'] = (int) $user['session_version'];
        $_SESSION['full_name'] = $user['full_name'];
        $_SESSION['email'] = $user['email'];

            // redircet user to browser
        header('Location: dashboard.php');
        exit;
    }

    $_SESSION['LoginErrors'] = [
        'Incorrect email address or password.'
    ];
    header('Location: login.php');
    exit;
} catch (PDOException $e) {
    error_log($e->getMessage());
    $_SESSION['LoginErrors'] = [
        'Unable to log in right now. Please try again.'
    ];
    header('Location: login.php');
    exit;
}

?>