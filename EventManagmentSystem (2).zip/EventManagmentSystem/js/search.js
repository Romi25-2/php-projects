// live search on search.php
(() => {
    const form = document.querySelector('form[action="searchProcess.php"]');
    const typeInput = document.getElementById('search-category');
    const queryInput = document.getElementById('search-query');
    const status = document.getElementById('live-search-status');
    const results = document.getElementById('live-search-results');
    const existingResults = document.querySelector('.search-results');

    if (!form || !typeInput || !queryInput || !status || !results) {
        return;
    }

    let debounceTimer = null;
    let activeController = null;
    let requestNumber = 0;

    const addText = (parent, tag, text) => {
        const element = document.createElement(tag);
        element.textContent = text ?? '';
        parent.append(element);
        return element;
    };

    const showResults = (items, type) => {
        results.replaceChildren();
        const heading = document.createElement('h2');
        heading.textContent = 'Live search results';
        results.append(heading);

        if (items.length === 0) {
            addText(results, 'p', 'No results found.');
            return;
        }

        for (const item of items) {
            const card = document.createElement('article');
            card.className = type === 'events' ? 'event-card' : 'user-card';

            if (type === 'events') {
                addText(card, 'h3', item.title);
                addText(card, 'p', `Date: ${item.event_date}`);
                addText(card, 'p', `Location: ${item.location ?? ''}`);
                addText(card, 'p', `Organiser: ${item.organiser}`);
                addText(card, 'p', item.description);
            } else {
                addText(card, 'h3', item.full_name);

                if (item.profile_picture) {
                    const image = document.createElement('img');
                    // stored as either "name.jpg" or a full path
                    
                    image.src = `uploads/profiles/${encodeURIComponent(
                        String(item.profile_picture).split(/[\\/]/).pop()
                    )}`;
                    image.alt = 'Profile picture';
                    image.width = 80;
                    image.height = 80;
                    image.style.objectFit = 'cover';
                    image.style.borderRadius = '50%';
                    card.append(image);
                }

                if (item.created_at) {
                    addText(card, 'p', `Member since ${item.created_at}`);
                }

                const link = document.createElement('a');
                link.href = `profile.php?id=${encodeURIComponent(item.user_id)}`;
                link.textContent = 'View Profile';
                card.append(link);
            }

            results.append(card);
        }
    };

    const runSearch = async () => {
        const query = queryInput.value.trim();
        const type = typeInput.value;
        const currentRequest = ++requestNumber;

        if (activeController) {
            activeController.abort();
        }
        results.replaceChildren();
        if (existingResults) {
            existingResults.hidden = query.length > 0;
        }

        if (query.length < 2) {
            status.textContent = query.length === 0
                ? ''
                : 'Type at least 2 characters to search.';
            return;
        }

        status.textContent = 'Searching…';
        activeController = new AbortController();

        try {
            const params = new URLSearchParams({
                search_type: type,
                query
            });
            const response = await fetch(`liveSearch.php?${params}`, {
                headers: { Accept: 'application/json' },
                signal: activeController.signal
            });
            const data = await response.json();

            if (currentRequest !== requestNumber) {
                return;
            }
            if (!response.ok) {
                throw new Error(data.error || 'Search failed. Please try again.');
            }

            status.textContent = '';
            showResults(Array.isArray(data.results) ? data.results : [], type);
        } catch (error) {
            if (error.name === 'AbortError' || currentRequest !== requestNumber) {
                return;
            }
            status.textContent = error.message || 'Search failed. Please try again.';
        }
    };

    const scheduleSearch = () => {
        window.clearTimeout(debounceTimer);
        debounceTimer = window.setTimeout(runSearch, 250);
    };

    queryInput.addEventListener('input', scheduleSearch);
    typeInput.addEventListener('change', scheduleSearch);
    form.addEventListener('submit', (event) => {
        if (queryInput.value.trim().length >= 2) {
            event.preventDefault();
            window.clearTimeout(debounceTimer);
            runSearch();
        }
    });
})();
