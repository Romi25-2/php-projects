(() => {
    const maxImageBytes = 2 * 1024 * 1024;
    const allowedImageTypes = new Set([
        'image/jpeg',
        'image/png',
        'image/webp'
    ]);
    const utf8Length = (value) => new TextEncoder().encode(value).length;

    const validateField = (field) => {
        const value = field.value.trim();
        let message = '';

        //validate form fields individualy
        if (field.name === 'fullName' || field.name === 'full_name') {
            if (value === '') {
                message = 'Enter your full name.';
            } else if (value.length > 255) {
                message = 'Your name must not exceed 255 characters.';
            }
        } else if (field.name === 'password' && field.form) {
            const confirmField = field.form.querySelector(
                '[name="confirmPass"], [name="confirm_password"]'
            );
            const isAccountPassword = Boolean(confirmField);

            if (isAccountPassword && value.length < 8) {
                message = 'Password must contain at least 8 characters.';
            } else if (utf8Length(field.value) > 72) {
                message = 'Password must not exceed 72 bytes.';
            }
        } else if (
            field.name === 'confirmPass' ||
            field.name === 'confirm_password'
        ) {
            const password = field.form.querySelector('[name="password"]');
            if (password && field.value !== password.value) {
                message = 'Passwords do not match.';
            }
        } else if (field.name === 'title' && value.length > 150) {
            message = 'Event titles must not exceed 150 characters.';
        } else if (field.name === 'location' && value.length > 200) {
            message = 'Locations must not exceed 200 characters.';
        } else if (field.name === 'message_text' && value.length > 5000) {
            message = 'Messages must not exceed 5000 characters.';
        } else if (field.name === 'query' && value.length < 2) {
            message = 'Enter at least 2 characters to search.';
        } else if (
            field.name === 'event_date' &&
            field.value !== '' &&
            Number.isNaN(Date.parse(field.value))
        ) {
            message = 'Enter a valid event date and time.';
        }

        field.setCustomValidity(message);
        return message === '';
    };
// added a live image preview functionality for file upload input during registrtaion
    const addImagePreview = (field) => {
        let preview = field.nextElementSibling;
        if (!preview || !preview.classList.contains('client-image-preview')) {
            preview = document.createElement('div');
            preview.className = 'client-image-preview';
            preview.setAttribute('aria-live', 'polite');
            field.insertAdjacentElement('afterend', preview);
        }

        let previewUrl = null;
        const clearPreview = () => {
            if (previewUrl) {
                URL.revokeObjectURL(previewUrl);
                previewUrl = null;
            }
            preview.replaceChildren();
        };

        field.addEventListener('change', () => {
            clearPreview();
            field.setCustomValidity('');

            const file = field.files && field.files[0];
            if (!file) {
                return;
            }

            if (!allowedImageTypes.has(file.type)) {
                field.setCustomValidity('Choose a JPG, PNG, or WEBP image.');
                field.reportValidity();
                field.value = '';
                return;
            }

            if (file.size > maxImageBytes) {
                field.setCustomValidity('The image must not exceed 2 MB.');
                field.reportValidity();
                field.value = '';
                return;
            }

            previewUrl = URL.createObjectURL(file);
            const image = document.createElement('img');
            image.src = previewUrl;
            image.alt = 'Preview of selected profile picture';
            image.width = 160;
            image.height = 160;
            image.style.objectFit = 'cover';
            preview.append(image);
        });

        field.form?.addEventListener('submit', (event) => {
            const file = field.files && field.files[0];
            field.setCustomValidity('');

            if (!file && field.required) {
                field.setCustomValidity('Choose a profile picture.');
            } else if (file && !allowedImageTypes.has(file.type)) {
                field.setCustomValidity('Choose a JPG, PNG, or WEBP image.');
            } else if (file && file.size > maxImageBytes) {
                field.setCustomValidity('The image must not exceed 2 MB.');
            }

            if (!field.checkValidity()) {
                event.preventDefault();
                field.reportValidity();
            }
        });

        window.addEventListener('beforeunload', clearPreview);
    };

    // validation listners to all interactive fields ad forms 
    document.querySelectorAll('form').forEach((form) => {
        const fields = Array.from(form.querySelectorAll(
            'input:not([type="hidden"]):not([type="file"]), textarea, select'
        ));

        fields.forEach((field) => {
            field.addEventListener('input', () => {
                validateField(field);
                //validate password cofnfirmation field live 
                if (field.name === 'password' && field.form) {
                    const confirmField = field.form.querySelector(
                        '[name="confirmPass"], [name="confirm_password"]'
                    );
                    if (confirmField) {
                        validateField(confirmField);
                    }
                }
            });
            field.addEventListener('change', () => validateField(field));
        });

        form.addEventListener('submit', (event) => {
            let valid = true;
            fields.forEach((field) => {
                if (!validateField(field)) {
                    valid = false;
                }
            });

            if (!form.checkValidity() || !valid) {
                event.preventDefault();
                form.reportValidity();
            }
        });
    });

    //initialise image preview
    document.querySelectorAll('input[type="file"][accept*="image"]').forEach(
        addImagePreview
    );
})();
