<?php
require_once __DIR__ . '/../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;

function sendPasswordResetEmail(string $recipient, string $resetToken): void
{
    $host = getenv('SMTP_HOST');
    $port = filter_var(getenv('SMTP_PORT'), FILTER_VALIDATE_INT);
    $username = getenv('SMTP_USERNAME');
    $password = getenv('SMTP_PASSWORD');
    $encryption = strtolower((string) getenv('SMTP_ENCRYPTION'));
    $fromAddress = getenv('MAIL_FROM_ADDRESS');
    $fromName = getenv('MAIL_FROM_NAME');
    $baseUrl = getenv('APP_BASE_URL');
    $parsedBaseUrl = is_string($baseUrl) ? parse_url($baseUrl) : false;

    if (
        !filter_var($recipient, FILTER_VALIDATE_EMAIL) ||
        !preg_match('/\A[a-f0-9]{64}\z/i', $resetToken) ||
        !is_string($host) || $host === '' || preg_match('/\s/', $host) ||
        $port === false || $port < 1 || $port > 65535 ||
        !is_string($username) || $username === '' ||
        !is_string($password) || $password === '' ||
        !in_array($encryption, ['tls', 'ssl'], true) ||
        !is_string($fromAddress) || !filter_var($fromAddress, FILTER_VALIDATE_EMAIL) ||
        !is_string($fromName) || trim($fromName) === '' ||
        preg_match('/[\r\n]/', $fromName) ||
        !is_array($parsedBaseUrl) ||
        strtolower((string) ($parsedBaseUrl['scheme'] ?? '')) !== 'https' ||
        empty($parsedBaseUrl['host']) ||
        isset($parsedBaseUrl['user']) ||
        isset($parsedBaseUrl['pass']) ||
        isset($parsedBaseUrl['query']) ||
        isset($parsedBaseUrl['fragment'])
    ) {
        throw new RuntimeException('Password-reset email configuration is incomplete or invalid.');
    }

    $resetUrl = rtrim($baseUrl, '/')
        . '/reset_password.php?token='
        . rawurlencode($resetToken);

    $mailer = new PHPMailer(true);
    $mailer->isSMTP();
    $mailer->Host = $host;
    $mailer->Port = $port;
    $mailer->SMTPAuth = true;
    $mailer->Username = $username;
    $mailer->Password = $password;
    $mailer->SMTPSecure = $encryption === 'tls'
        ? PHPMailer::ENCRYPTION_STARTTLS
        : PHPMailer::ENCRYPTION_SMTPS;
    $mailer->CharSet = 'UTF-8';
    $mailer->setFrom($fromAddress, $fromName);
    $mailer->addAddress($recipient);
    $mailer->Subject = 'Password reset request';
    $safeUrl = htmlspecialchars($resetUrl, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    $mailer->isHTML(true);
    $mailer->Body = '<p>Use this link to reset your password. It expires in 30 minutes.</p>'
        . '<p><a href="' . $safeUrl . '">Reset your password</a></p>'
        . '<p>If you did not request a reset, you can ignore this email.</p>';
    $mailer->AltBody = "Use this link to reset your password. It expires in 30 minutes:\n"
        . $resetUrl
        . "\nIf you did not request a reset, you can ignore this email.";
    $mailer->send();
}
