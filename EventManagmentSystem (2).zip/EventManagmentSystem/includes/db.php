<?php
$host = getenv('EVENT_DB_HOST') ?: 'localhost';
$dbname = getenv('EVENT_DB_NAME') ?: 'eventmanagement_db';
$username = getenv('EVENT_DB_USER');
$password = getenv('EVENT_DB_PASSWORD');

if ($username === false || $username === '' || $password === false || $password === '') {
    error_log('EVENT_DB_USER and EVENT_DB_PASSWORD must be configured.');
    exit('Database connection configuration is incomplete.');
}

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $username,
        $password,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );
} catch (PDOException $e) {
    error_log($e->getMessage());
    exit('Database connection failed.');
}

if (session_status() === PHP_SESSION_ACTIVE && isset($_SESSION['user_id'])) {
    $sessionVersion = $_SESSION['auth_session_version'] ?? null;

    if (!is_int($sessionVersion)) {
        $_SESSION = [];
        session_regenerate_id(true);
    } else {
        try {
            $stmt = $pdo->prepare(
                'SELECT session_version FROM users WHERE user_id = ?'
            );
            $stmt->execute([$_SESSION['user_id']]);
            $currentVersion = $stmt->fetchColumn();

            if (
                !is_numeric($currentVersion) ||
                (int) $currentVersion !== $sessionVersion
            ) {
                $_SESSION = [];
                session_regenerate_id(true);
            }
        } catch (PDOException $e) {
            error_log($e->getMessage());
            exit('Session validation failed.');
        }
    }
}
?>