<?php
require_once __DIR__ . '/includes/session.php';

require_once __DIR__ . '/includes/db.php';

// Check whether the user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

// Only accept form submissions
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: profile.php');
    exit;
}

$userId = (int) $_SESSION['user_id'];
$token = $_POST['csrf_token'] ?? '';
$fullName = is_string($_POST['full_name'] ?? null)
    ? trim($_POST['full_name'])
    : '';
$newPictureName = null;


if (
    !isset($_SESSION['profile_csrf_token']) ||
    !is_string($token) ||
    !hash_equals($_SESSION['profile_csrf_token'], $token)
) {
    $_SESSION['profile_errors'] = [
        "Invalid form submission. Please try again."
    ];

    header('Location: profile.php');
    exit;
}

// Validate the full name field
if ($fullName === '') {
    $_SESSION['profile_errors'] = ["Full name is required."];
} elseif (strlen($fullName) > 255) {
    $_SESSION['profile_errors'] = [
        "Full name must not exceed 255 characters."
    ];
}

if (!empty($_SESSION['profile_errors'])) {
    header('Location: profile.php');
    exit;
}

try {
    // Get the current profile picture from the database
    $stmt = $pdo->prepare(
        "SELECT pricture_picture FROM users WHERE user_id = ?"
    );
    $stmt->execute([$userId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        session_destroy();
        header('Location: login.php');
        exit;
    }

    $oldPictureName = $user['pricture_picture'] ?? null;

    // checking the file structure and upload
    if (
        isset($_FILES['profile_picture']) &&
        (
            !is_array($_FILES['profile_picture']) ||
            !isset($_FILES['profile_picture']['error'])
        )
    ) {
        throw new RuntimeException("The image could not be uploaded. Please try again.");
    }
//process picture upload if it was provided 
    if (
        isset($_FILES['profile_picture']) &&
        $_FILES['profile_picture']['error'] !== UPLOAD_ERR_NO_FILE
    ) {
        $file = $_FILES['profile_picture'];

        if (
            $file['error'] !== UPLOAD_ERR_OK ||
            !isset($file['tmp_name'], $file['size']) ||
            !is_string($file['tmp_name']) ||
            !is_numeric($file['size']) ||
            !is_uploaded_file($file['tmp_name'])
        ) {
            throw new RuntimeException(
                "The image could not be uploaded. Please try again."
            );
        }

        // Limit image size to 2 MB
        if ((int) $file['size'] > 2 * 1024 * 1024) {
            throw new RuntimeException(
                "The profile picture must not exceed 2 MB."
            );
        }

        // Check the fie type 
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mimeType = $finfo->file($file['tmp_name']);

        $allowedTypes = [
            'image/jpeg' => 'jpg',
            'image/png'  => 'png',
            'image/webp' => 'webp'
        ];

        if (!isset($allowedTypes[$mimeType])) {
            throw new RuntimeException(
                "Only JPG, PNG and WEBP images are allowed."
            );
        }

        if (@getimagesize($file['tmp_name']) === false) {
            throw new RuntimeException("The uploaded file is not a valid image.");
        }

        //  hecks if directory exist and if not creates a folder for it 
        $uploadDirectory = __DIR__ . '/uploads/profiles/';

        if (
            !is_dir($uploadDirectory) &&
            !mkdir($uploadDirectory, 0755, true) &&
            !is_dir($uploadDirectory)
        ) {
            throw new RuntimeException(
                "The upload folder could not be created."
            );
        }

        // Generate a safe filename instead of using the original filename
        $newPictureName = bin2hex(random_bytes(16))
            . '.' . $allowedTypes[$mimeType];

        $destination = $uploadDirectory . $newPictureName;

        if (!move_uploaded_file($file['tmp_name'], $destination)) {
            throw new RuntimeException(
                "The profile picture could not be saved."
            );
        }
    }

    // Update the profile name and the picture
    if ($newPictureName !== null) {
        $stmt = $pdo->prepare(
            "UPDATE users
             SET full_name = ?, pricture_picture = ?
             WHERE user_id = ?"
        );

        $stmt->execute([$fullName, $newPictureName, $userId]);
    } else {
        $stmt = $pdo->prepare(
            "UPDATE users
             SET full_name = ?
             WHERE user_id = ?"
        );

        $stmt->execute([$fullName, $userId]);
    }

    // Update the name displayed in  current session
    $_SESSION['full_name'] = $fullName;

    // Remove  previous pictur after the database update succeeds
    if (
        $newPictureName !== null &&
        !empty($oldPictureName) &&
        basename($oldPictureName) === $oldPictureName
    ) {
        $oldPicturePath = __DIR__
            . '/uploads/profiles/'
            . $oldPictureName;

        if (is_file($oldPicturePath)) {
            unlink($oldPicturePath);
        }
    }

    $_SESSION['profile_success'] = "Profile updated successfully.";

    header('Location: profile.php');
    exit;

} catch (RuntimeException $e) {
    // Remove  newly uploaded file if the operation failed
    if ($newPictureName !== null) {
        $newPath = __DIR__ . '/uploads/profiles/' . $newPictureName;

        if (is_file($newPath)) {
            unlink($newPath);
        }
    }

    $_SESSION['profile_errors'] = [$e->getMessage()];

    header('Location: profile.php');
    exit;

} catch (Throwable $e) {
    error_log($e->getMessage());

    // Avoid leaving an unused image behind
    if ($newPictureName !== null) {
        $newPath = __DIR__ . '/uploads/profiles/' . $newPictureName;

        if (is_file($newPath)) {
            unlink($newPath);
        }
    }

    $_SESSION['profile_errors'] = [
        "Unable to update your profile. Please try again."
    ];

    header('Location: profile.php');
    exit;
}
