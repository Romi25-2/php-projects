<?php
require_once __DIR__ . '/includes/session.php';

// fetches and clear session data this includes erro,success 
// -messages and old input
$errors = isset($_SESSION['errors']) && is_array($_SESSION['errors'])
    ? array_filter($_SESSION['errors'], 'is_string'): [];
$success = isset($_SESSION['success']) && is_string($_SESSION['success'])
    ? $_SESSION['success']: '';
$old = isset($_SESSION['old']) && is_array($_SESSION['old'])
    ? $_SESSION['old']: [];
$oldFullName = isset($old['fullName']) && is_string($old['fullName'])
    ? $old['fullName']: '';
$oldEmail = isset($old['email']) && is_string($old['email'])
    ? $old['email']: '';

//cear data when refreshed 
unset ($_SESSION['errors'],$_SESSION['success'], $_SESSION["old"]
        );

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create an Account | Eventora</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="js/client.js" defer></script>
</head>
<body>
    <h1>Create an Account</h1>

    <!-- display error messaGE -->
 <?php if(!empty($errors)): ?>
<?php  foreach ($errors as $error): ?> 
    <p class="flash--err">
       <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>  <!-- ENT_QUOTES preventing attackers from breaking out of attribute strings -->
    </p>
    <?php endforeach; ?>
 <?php endif; ?>
    
<!-- if the account is already registered or registration is a success ,
 the user can go to the login page directly -->
<?php if ($success !== ''): ?>
    <p class="flash--ok">
        <?= htmlspecialchars($success, ENT_QUOTES, 'UTF-8') ?>
    </p>  
    <a href="login.php">Go to Login</a>
    
<?php else: ?> 
    <form action="registrationProcess.php" method="POST" enctype="multipart/form-data">

        <label>Full Name: </label>
        <input type="text" name="fullName" maxLength="255" id="full-name" 
        value="<?= htmlspecialchars(
                       $oldFullName,
                       ENT_QUOTES,
                       'UTF-8'
                   ) ?>" required><br><br>

        <label>Email </label>
        <input type="email" name="email" maxlength="150" id="account-email" value="<?= htmlspecialchars(
                       $oldEmail,
                       ENT_QUOTES,
                       'UTF-8'
                   ) ?>" required><br><br>

        <label>Password</label>
        <input type="password" name="password" id="account-password" maxlength="72" required><br><br>

        <label>Confirm Password</label>
        <input type="password" name="confirmPass" id="confirmPass" maxlength="72" required><br><br>

        <label for="profile-picture">Profile Picture (optional; JPG, PNG or WEBP; max 2 MB)</label>
        <input
            type="file"
            name="profile_picture"
            id="profile-picture"
            accept="image/jpeg,image/png,image/webp"
        ><br><br>

        <input type="submit" name="register" value="Register">

    </form>
    <p>Aready have an account? <a href="login.php">Login</a></p>
<?php endif; ?>
</body>
</html>