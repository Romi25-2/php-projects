<?php
require_once __DIR__ . '/includes/session.php';
header('Content-Type: application/json; charset=utf-8');

// ensure user is authenticated before allowing search
if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Please sign in to search.']);
    exit;
}
// restrict to get request only 
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    header('Allow: GET');
    echo json_encode(['error' => 'Method not allowed.']);
    exit;
}

// santizes and retieve search parameters 
$searchType = is_string($_GET['search_type'] ?? null)
    ? $_GET['search_type']: '';
$query = is_string($_GET['query'] ?? null)
    ? trim($_GET['query']): '';

    // validate that  search type is supported 
if (!in_array($searchType, ['events', 'users'], true)) {
    http_response_code(400);
    echo json_encode(['error' => 'Choose events or users to search.']);
    exit;
}

if (strlen($query) < 2 || strlen($query) > 100) {
    http_response_code(400);
    echo json_encode(['error' => 'Enter between 2 and 100 characters to search.']);
    exit;
}

require_once __DIR__ . '/includes/db.php';

// executes search based on the selected category
try {
    $searchTerm = '%' . $query . '%';

    if ($searchType === 'events') {
        $stmt = $pdo->prepare(
            "SELECT events.event_id,
                    events.title,
                    events.description,
                    events.event_date,
                    events.location,
                    users.full_name AS organiser
             FROM events
             INNER JOIN users ON events.user_id = users.user_id
             WHERE events.title LIKE ?
                OR events.location LIKE ?
             ORDER BY
                CASE WHEN events.event_date >= NOW() THEN 0 ELSE 1 END,
                events.event_date ASC
             LIMIT 20"
        );
        $stmt->execute([$searchTerm, $searchTerm]);
    } else {
        $stmt = $pdo->prepare(
            "SELECT user_id,
                    full_name,
                    pricture_picture AS profile_picture,
                    create_at AS created_at
             FROM users
             WHERE full_name LIKE ?
             ORDER BY full_name ASC
             LIMIT 20"
        );
        $stmt->execute([$searchTerm]);
    }

    echo json_encode(
        ['results' => $stmt->fetchAll(PDO::FETCH_ASSOC)],
        JSON_INVALID_UTF8_SUBSTITUTE
    );
} catch (PDOException $e) {
    error_log($e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Search failed. Please try again.']);
}
