<?php
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/includes/db.php';

$success = '';
$error = '';
$email = '';
$successMessage = "If an account exists with that email, a password reset link has been generated.";

unset($_SESSION['development_reset_link']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrfToken = $_POST['csrf_token'] ?? '';
    if (
        !is_string($csrfToken) ||
        !isset($_SESSION['csrf_token']) ||
        !hash_equals($_SESSION['csrf_token'], $csrfToken)
    ) {
        http_response_code(403);
        $error = 'Invalid form submission. Please try again.';
    } else {
        $email = is_string($_POST['email'] ?? null)
            ? trim($_POST['email'])
            : '';

        try {
            $remoteAddress = $_SERVER['REMOTE_ADDR'] ?? '';
            if (
                !is_string($remoteAddress) ||
                filter_var($remoteAddress, FILTER_VALIDATE_IP) === false
            ) {
                throw new RuntimeException('Could not determine the client IP for rate limiting.');
            }

            $bucketStart = gmdate('Y-m-d H:i:s', intdiv(time(), 900) * 900);
            $rateKeys = [
                'ip' => hash('sha256', 'ip:' . $remoteAddress)
            ];
            if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $rateKeys['email'] = hash('sha256', 'email:' . strtolower($email));
            }

            $pdo->exec(
                'DELETE FROM password_reset_rate_limits
                 WHERE window_start < UTC_TIMESTAMP() - INTERVAL 1 DAY'
            );

            $rateLimited = false;
            foreach ($rateKeys as $dimension => $rateKey) {
                $stmt = $pdo->prepare(
                    'INSERT INTO password_reset_rate_limits
                        (subject_hash, window_start, request_count)
                     VALUES (?, ?, 1)
                     ON DUPLICATE KEY UPDATE request_count = request_count + 1'
                );
                $stmt->execute([$rateKey, $bucketStart]);

                $stmt = $pdo->prepare(
                    'SELECT request_count
                     FROM password_reset_rate_limits
                     WHERE subject_hash = ? AND window_start = ?'
                );
                $stmt->execute([$rateKey, $bucketStart]);
                $requestCount = (int) $stmt->fetchColumn();
                $limit = $dimension === 'ip' ? 5 : 3;
                if ($requestCount > $limit) {
                    $rateLimited = true;
                }
            }

            if ($rateLimited) {
                $success = $successMessage;
            } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $error = 'Please enter a valid email address.';
            } else {
                $stmt = $pdo->prepare('SELECT user_id FROM users WHERE email = ?');
                $stmt->execute([$email]);
                $user = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($user) {
                    $token = bin2hex(random_bytes(32));
                    $tokenHash = hash('sha256', $token);
                    $expiresAt = date('Y-m-d H:i:s', time() + (30 * 60));

                    $stmt = $pdo->prepare(
                        'UPDATE users
                         SET reset_token_hash = ?,
                             reset_expires_at = ?
                         WHERE user_id = ?'
                    );
                    $stmt->execute([$tokenHash, $expiresAt, $user['user_id']]);

                    $appEnvironment = strtolower((string) (getenv('APP_ENV') ?: 'production'));
                    $isLocalRequest = in_array(
                        $remoteAddress,
                        ['127.0.0.1', '::1'],
                        true
                    );

                    if ($appEnvironment === 'development' && $isLocalRequest) {
                        $_SESSION['development_reset_link'] =
                            'reset_password.php?token=' . urlencode($token);
                    } else {
                        try {
                            require_once __DIR__ . '/includes/password_reset_mailer.php';
                            sendPasswordResetEmail($email, $token);
                        } catch (Throwable $e) {
                            $stmt = $pdo->prepare(
                                'UPDATE users
                                 SET reset_token_hash = NULL, reset_expires_at = NULL
                                 WHERE user_id = ? AND reset_token_hash = ?'
                            );
                            $stmt->execute([$user['user_id'], $tokenHash]);
                            throw $e;
                        }
                    }
                }

                $success = $successMessage;
            }
        } catch (PDOException $e) {
            error_log($e->getMessage());
            $error = 'Something went wrong. Please try again later.';
        } catch (Throwable $e) {
            error_log($e->getMessage());
            $error = 'Something went wrong. Please try again later.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password | Eventora</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="js/client.js" defer></script>
</head>
<body>

<div class="page-wrap">
    <h1>Forgot Password</h1>

    <p>Enter your email address to request a password reset.</p>
    <!-- display error message if validaation or system errors occurs -->
    <?php if ($error !== ''): ?>
        <p class="flash--err">
            <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
        </p>
    <?php endif; ?>

    <!-- success message displayed -->
    <?php if ($success !== ''): ?>
        <p class="flash--ok">
            <?= htmlspecialchars($success, ENT_QUOTES, 'UTF-8') ?>
        </p>
    <?php endif; ?>

    <form action="forgotPass.php" method="POST">
        <input
            type="hidden"
            name="csrf_token"
            value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>"
        >
        <label for="account-email">Email Address:</label>

        <input
            type="email"
            name="email"
            id="account-email"
            maxlength="150"
            value="<?= htmlspecialchars($email, ENT_QUOTES, 'UTF-8') ?>"
            required
        >

        <button type="submit">Request Reset Link</button>
    </form>
    <!-- Shown only for local requests when APP_ENV=development. -->
    <?php if (isset($_SESSION['development_reset_link'])): ?>
        <p><strong>Local testing link:</strong></p>

        <p>
            <a href="<?= htmlspecialchars($_SESSION['development_reset_link'], ENT_QUOTES, 'UTF-8') ?>">
                Open password reset page
            </a>
        </p>

        <?php unset($_SESSION['development_reset_link']); ?>
    <?php endif; ?>

    <p><a href="login.php">Return to Login</a></p>
</div>

</body>
</html>
