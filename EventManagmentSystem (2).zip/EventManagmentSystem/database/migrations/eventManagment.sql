USE eventmanagement_db;

/* stop individual users name, email, hashed pasword and 
profile pictures.The reset-token fiels, suport secure
 passwors recovery  */
CREATE TABLE users (
	user_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(255) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(100) NOT NULL,
    pricture_picture VARCHAR(255) NULL DEFAULT NULL,
    reset_token_hash VARCHAR(64)DEFAULT NULL,
    reset_expires_at DATETIME DEFAULT NULL,
    session_version INT UNSIGNED NOT NULL DEFAULT 0,
    create_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

/* stores event details, the creators ID, the event date and timestamp
*/ 
CREATE TABLE events(
	event_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR (150) NOT NULL,
    description TEXT,
    event_date DATETIME NOT NULL,
    location VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    update_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
		ON UPDATE CURRENT_TIMESTAMP,
        
	FOREIGN KEY (user_id) REFERENCES users(user_id) 
    ON DELETE CASCADE

);

CREATE TABLE messages(
	message_id INT AUTO_INCREMENT PRIMARY KEY,
    sender_id INT NOT NULL,
    receiver_id INT NOT NULL,
    message_text TEXT NOT NULL,
    is_read BOOLEAN NOT NULL DEFAULT FALSE,
    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY(sender_id) REFERENCES users(user_id) 
    ON DELETE CASCADE,
    
    FOREIGN KEY (receiver_id) REFERENCES users(user_id)
    ON DELETE CASCADE,
    
    INDEX idx_sender_receiver (sender_id, receiver_id,sent_at),
    INDEX idx_receiver_sender (receiver_id, sender_id, sent_at)    
);

CREATE TABLE password_reset_rate_limits (
    subject_hash CHAR(64) NOT NULL,
    window_start DATETIME NOT NULL,
    request_count INT UNSIGNED NOT NULL,
    PRIMARY KEY (subject_hash, window_start),
    INDEX idx_password_reset_rate_window (window_start)
);