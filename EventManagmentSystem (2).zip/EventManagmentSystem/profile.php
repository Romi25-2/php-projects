<?php
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/includes/db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$currentUserId = (int) $_SESSION['user_id'];
$fullName = $_SESSION['full_name'] ?? '';
$requestedId = $_GET['id'] ?? null;

//needs to check if user is viewing their own or another users profile
if ($requestedId === null) {
    $profileId = $currentUserId;
} elseif (
    !is_string($requestedId) ||
    filter_var($requestedId, FILTER_VALIDATE_INT) === false ||
    (int) $requestedId < 1
) {
    http_response_code(400);
    exit('Invalid profile.');
} else {
    $profileId = (int) $requestedId;
}

// fetch user details from the databse
$stmt = $pdo->prepare(
    'SELECT user_id, full_name, pricture_picture, create_at
     FROM users
     WHERE user_id = ?'
);
$stmt->execute([$profileId]);
$profile = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$profile) {
    http_response_code(404);
    exit('Profile not found.');
}

$isOwnProfile = (int) $profile['user_id'] === $currentUserId;
$errors = $_SESSION['profile_errors'] ?? [];
$success = $_SESSION['profile_success'] ?? '';
unset($_SESSION['profile_errors'], $_SESSION['profile_success']);

if (!is_array($errors)) {
    $errors = [];
}
$errors = array_filter($errors, 'is_string');
$success = is_string($success) ? $success : '';

if ($isOwnProfile && empty($_SESSION['profile_csrf_token'])) {
    $_SESSION['profile_csrf_token'] = bin2hex(random_bytes(32));
}

$pictureName = $profile['pricture_picture'] ?? '';
$pictureName = is_string($pictureName) ? basename($pictureName) : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($profile['full_name'], ENT_QUOTES, 'UTF-8') ?> | Profile | Eventora</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="js/client.js" defer></script>
</head>
<body>
<header class="site-header">
    <div class="header-left">
        <a class="brand" href="dashboard.php" aria-label="Eventora home">
            <span class="brand-name">Eventora</span>
        </a>
        <nav aria-label="Main navigation">
            <ul class="header-nav-list">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="events.php#create-event">Create Event</a></li>
                <li><a href="search.php">Search</a></li>
                <li><a href="messages.php">Messages</a></li>
            </ul>
        </nav>
    </div>
    <div class="header-actions">
        <a class="header-user" href="profile.php"<?= $isOwnProfile ? ' aria-current="page"' : '' ?>>
            <?= htmlspecialchars($fullName, ENT_QUOTES, 'UTF-8') ?>
        </a>
        <form action="logoutProcess.php" method="post">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">
            <button class="header-logout" type="submit">Logout</button>
        </form>
    </div>
</header>

<main class="page-wrap">
    <h2><?= $isOwnProfile ? 'My Profile' : 'User Profile' ?></h2>

    <?php foreach ($errors as $error): ?>
        <p class="flash--err"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
    <?php endforeach; ?>

    <?php if ($success !== ''): ?>
        <p class="flash--ok"><?= htmlspecialchars($success, ENT_QUOTES, 'UTF-8') ?></p>
    <?php endif; ?>

    <section class="profile-view">
        <?php if ($pictureName !== ''): ?>
            <img
                src="uploads/profiles/<?= rawurlencode($pictureName) ?>"
                alt="Profile picture for <?= htmlspecialchars($profile['full_name'], ENT_QUOTES, 'UTF-8') ?>"
                width="160"
                height="160"
                style="object-fit: cover; border-radius: 50%;"
            >
        <?php else: ?>
            <p>No profile picture uploaded.</p>
        <?php endif; ?>

        <p>
            <strong>Name:</strong>
            <?= htmlspecialchars($profile['full_name'], ENT_QUOTES, 'UTF-8') ?>
        </p>

        <?php if (!empty($profile['create_at'])): ?>
            <p>
                <strong>Joined since:</strong>
                <?= htmlspecialchars(
                    date('d M Y', strtotime($profile['create_at'])),
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>
            </p>
        <?php endif; ?>
    </section>

    <!-- avaliable when you are viewing your own profile -->
    <?php if ($isOwnProfile): ?>
        <section class="profile-form">
            <h3>Update Profile</h3>
            <form action="profileProcess.php" method="POST" enctype="multipart/form-data">
                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= htmlspecialchars($_SESSION['profile_csrf_token'], ENT_QUOTES, 'UTF-8') ?>"
                >

                <label for="full-name">Full Name</label>
                <input
                    type="text"
                    name="full_name"
                    id="full-name"
                    maxlength="255"
                    value="<?= htmlspecialchars($profile['full_name'], ENT_QUOTES, 'UTF-8') ?>"
                    required
                >

                <label for="profile-picture">New Profile Picture (JPG, PNG or WEBP; max 2 MB)</label>
                <input
                    type="file"
                    name="profile_picture"
                    id="profile-picture"
                    accept="image/jpeg,image/png,image/webp"
                >
                <button type="submit">Save Profile</button>
            </form>
        </section>
    <?php endif; ?>
</main>
</body>
</html>
