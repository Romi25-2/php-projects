<?php
    require_once __DIR__ . '/includes/session.php';

    require_once __DIR__ . '/includes/db.php';

// Only logged-in users can access this page
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$userId = (int) $_SESSION['user_id'];
$fullName = $_SESSION['full_name'] ?? '';

// Create a CSRF token
if (empty($_SESSION['events_csrf_token'])) {
    $_SESSION['events_csrf_token'] = bin2hex(random_bytes(32));
}

// Display messages from the processing file
$errors = $_SESSION['event_errors'] ?? [];
$success = $_SESSION['event_success'] ?? '';

unset($_SESSION['event_errors'], $_SESSION['event_success']);

// Get event details if the user is editing their own event
$editEvent = null;
$editId = filter_input(INPUT_GET, 'edit', FILTER_VALIDATE_INT);

if ($editId) {
    //fetch event if it belongs to the registered user 
    $stmt = $pdo->prepare(
        "SELECT event_id, title, description, event_date, location
         FROM events
         WHERE event_id = ? AND user_id = ?"
    );

    $stmt->execute([$editId, $userId]);
    $editEvent = $stmt->fetch(PDO::FETCH_ASSOC);
}

// fetchall  events, with upcoming events first
$stmt = $pdo->prepare(
    "SELECT events.*, users.full_name AS organiser
     FROM events
     INNER JOIN users ON events.user_id = users.user_id
     ORDER BY
         CASE WHEN events.event_date >= NOW() THEN 0 ELSE 1 END,
         CASE WHEN events.event_date >= NOW()
              THEN events.event_date END ASC,
         CASE WHEN events.event_date < NOW()
              THEN events.event_date END DESC"
);

$stmt->execute();
$events = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Events | Eventora</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="js/client.js" defer></script>
</head>
<body>

<header class="site-header">
    <div class="header-left">
        <a class="brand" href="dashboard.php" aria-label="Eventora home">
            <span class="brand-name">Eventora</span>
        </a>
        <nav aria-label="Main navigation">
            <ul class="header-nav-list">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="events.php#create-event" aria-current="page">Create Event</a></li>
                <li><a href="search.php">Search</a></li>
                <li><a href="messages.php">Messages</a></li>
            </ul>
        </nav>
    </div>
    <div class="header-actions">
        <a class="header-user" href="profile.php">
            <?= htmlspecialchars($fullName, ENT_QUOTES, 'UTF-8') ?>
        </a>
        <form action="logoutProcess.php" method="post">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">
            <button class="header-logout" type="submit">Logout</button>
        </form>
    </div>
</header>

<main>
    <h2>Manage Events</h2>

    <?php foreach ($errors as $error): ?>
        <p class="flash--err">
            <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
        </p>
    <?php endforeach; ?>
<!-- display success pop up if set -->
    <?php if ($success !== ''): ?>
        <p class="flash--ok">
            <?= htmlspecialchars($success, ENT_QUOTES, 'UTF-8') ?>
        </p>
    <?php endif; ?>

    <!-- switches dynamically from create and edit modes -->
    <section class="event-form" id="create-event">
        <h2><?= $editEvent ? 'Edit Event' : 'Create an Event' ?></h2>

        <?php if ($editId && !$editEvent): ?>
            <p class="flash--err">Event not found or you do not have permission to edit it.</p>
        <?php endif; ?>

        <!-- switches to event process php  -->
        <form action="eventProcess.php" method="POST">
            <input type="hidden" name="csrf_token"
                   value="<?= htmlspecialchars($_SESSION['events_csrf_token'], ENT_QUOTES, 'UTF-8') ?>">

            <input type="hidden" name="action"
                   value="<?= $editEvent ? 'update' : 'create' ?>">

            <?php if ($editEvent): ?>
                <input type="hidden" name="event_id"
                       value="<?= (int) $editEvent['event_id'] ?>">
            <?php endif; ?>

            <label for="event-title">Event Title</label>
            <input type="text" id="event-title" name="title" maxlength="150"
                   value="<?= htmlspecialchars($editEvent['title'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
                   required>

            <label for="event-description">Description</label>
            <textarea id="event-description" name="description" rows="4" required><?= htmlspecialchars($editEvent['description'] ?? '', ENT_QUOTES, 'UTF-8') ?></textarea>

            <label for="event-date">Date and Time</label>
            <input type="datetime-local" id="event-date" name="event_date"
                   value="<?= $editEvent ? htmlspecialchars(date('Y-m-d\TH:i', strtotime($editEvent['event_date'])), ENT_QUOTES, 'UTF-8') : '' ?>"
                   required>

            <label for="event-location">Location</label>
            <input type="text" id="event-location" name="location" maxlength="200"
                   value="<?= htmlspecialchars($editEvent['location'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
                   required>

            <button type="submit">
                <?= $editEvent ? 'Save Changes' : 'Create Event' ?>
            </button>

            <?php if ($editEvent): ?>
                <a href="events.php">Cancel</a>
            <?php endif; ?>
        </form>
    </section>

<!-- Event listing -->
    <section class="event-list">
        <h2>All Events</h2>

        <?php if (empty($events)): ?>
            <p>No events have been created yet.</p>
        <?php else: ?>

            <?php foreach ($events as $event): ?>
                <article class="event-card">
                    <h3><?= htmlspecialchars($event['title'], ENT_QUOTES, 'UTF-8') ?></h3>

                    <p>
                        <strong>Date:</strong>
                        <?= htmlspecialchars(date('d M Y, H:i', strtotime($event['event_date'])), ENT_QUOTES, 'UTF-8') ?>
                    </p>

                    <p>
                        <strong>Location:</strong>
                        <?= htmlspecialchars($event['location'], ENT_QUOTES, 'UTF-8') ?>
                    </p>

                    <p>
                        <strong>Organiser:</strong>
                        <?= htmlspecialchars($event['organiser'], ENT_QUOTES, 'UTF-8') ?>
                    </p>

                    <p>
                        <?= nl2br(htmlspecialchars($event['description'], ENT_QUOTES, 'UTF-8')) ?>
                    </p>

                <!-- edit and delete option is shown for events owend by 
                by current logged in user  -->
                    <?php if ((int) $event['user_id'] === $userId): ?>
                        <a href="events.php?edit=<?= (int) $event['event_id'] ?>">Edit</a>

                        <form action="eventProcess.php" method="POST"
                              onsubmit="return confirm('Are you sure you want to delete this event?');">

                            <input type="hidden" name="csrf_token"
                                   value="<?= htmlspecialchars($_SESSION['events_csrf_token'], ENT_QUOTES, 'UTF-8') ?>">

                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="event_id"
                                   value="<?= (int) $event['event_id'] ?>">

                            <button type="submit">Delete</button>
                        </form>
                    <?php endif; ?>
                </article>
            <?php endforeach; ?>

        <?php endif; ?>
    </section>
</main>

<footer>
    <p>&copy; <?= date('Y') ?> Eventora</p>
</footer>

</body>
</html>


?>