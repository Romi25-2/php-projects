<?php
require_once __DIR__ . '/includes/session.php';
require_once __DIR__ . '/includes/db.php';

// Only logged-in users can process events
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: events.php');
    exit;
}

$userId = (int) $_SESSION['user_id'];

//return requested action safely
$action = is_string($_POST['action'] ?? null)
    ? $_POST['action']
    : '';
//function to safely fetch trimmed post string
$postString = static function (string $key): string {
    return is_string($_POST[$key] ?? null)
        ? trim($_POST[$key])
        : '';
};

// token is given by events,.php and stored in this session
$csrfToken = $_POST['csrf_token'] ?? '';
if (
    empty($_SESSION['events_csrf_token']) ||
    !is_string($csrfToken) ||
    !hash_equals($_SESSION['events_csrf_token'], $csrfToken)
) {
    $_SESSION['event_errors'] = [
        "Invalid form submission. Please try again."
    ];

    header('Location: events.php');
    exit;
}

try {

    // Creating events 
    if ($action === 'create') {

        $title = $postString('title');
        $description = $postString('description');
        $eventDate = $postString('event_date');
        $location = $postString('location');

        $errors = [];

        //return error and datetime or nul 
        if ($title === '' || strlen($title) > 150) {
            $errors[] = "Enter an event title of no more than 150 characters.";
        }

        if ($description === '') {
            $errors[] = "Event description is required.";
        }

        if ($location === '' || strlen($location) > 200) {
            $errors[] = "Enter a location of no more than 200 characters.";
        }

        // Validate the date and time
        $date = DateTime::createFromFormat('!Y-m-d\TH:i', $eventDate);
        $dateErrors = DateTime::getLastErrors();


        if (
            !$date ||
            ($dateErrors !== false &&
                ($dateErrors['warning_count'] > 0 || $dateErrors['error_count'] > 0)) ||
            $date->format('Y-m-d\TH:i') !== $eventDate
        ) {
            $errors[] = "Enter a valid event date and time.";
        }

        if (!empty($errors)) {
            $_SESSION['event_errors'] = $errors;
            header('Location: events.php');
            exit;
        }

        $sqlDate = $date->format('Y-m-d H:i:s');

        $stmt = $pdo->prepare(
            "INSERT INTO events
                (user_id, title, description, event_date, location)
             VALUES (?, ?, ?, ?, ?)"
        );

        $stmt->execute([
            $userId,
            $title,
            $description,
            $sqlDate,
            $location
        ]);

        $_SESSION['event_success'] = "Event created successfully.";

    // UPDATE EVENT
    } elseif ($action === 'update') {

        $eventId = filter_input(INPUT_POST, 'event_id', FILTER_VALIDATE_INT);

        if (!$eventId || $eventId < 1) {
            $_SESSION['event_errors'] = ["Invalid event selected."];
            header('Location: events.php');
            exit;
        }

        $title = $postString('title');
        $description = $postString('description');
        $eventDate = $postString('event_date');
        $location = $postString('location');

        $errors = [];

        if ($title === '' || strlen($title) > 150) {
            $errors[] = "Enter an event title of no more than 150 characters.";
        }

        if ($description === '') {
            $errors[] = "Event description is required.";
        }

        if ($location === '' || strlen($location) > 200) {
            $errors[] = "Enter a location of no more than 200 characters.";
        }

        $date = DateTime::createFromFormat('!Y-m-d\TH:i', $eventDate);
        $dateErrors = DateTime::getLastErrors();

        if (
            !$date ||
            ($dateErrors !== false &&
                ($dateErrors['warning_count'] > 0 || $dateErrors['error_count'] > 0)) ||
            $date->format('Y-m-d\TH:i') !== $eventDate
        ) {
            $errors[] = "Enter a valid event date and time.";
        }

        if (!empty($errors)) {
            $_SESSION['event_errors'] = $errors;
            header('Location: events.php?edit=' . $eventId);
            exit;
        }

        // Update only if the logged-in user owns the event
        $stmt = $pdo->prepare(
            "UPDATE events
             SET title = ?, description = ?, event_date = ?, location = ?
             WHERE event_id = ? AND user_id = ?"
        );

        $stmt->execute([
            $title,
            $description,
            $date->format('Y-m-d H:i:s'),
            $location,
            $eventId,
            $userId
        ]);

        if ($stmt->rowCount() === 0) {
            // Check whether the event exists and belongs to this user
            //only treat the first 2 as a error
            $check = $pdo->prepare(
                "SELECT event_id FROM events
                 WHERE event_id = ? AND user_id = ?"
            );
            $check->execute([$eventId, $userId]);

            if (!$check->fetch()) {
                $_SESSION['event_errors'] = [
                    "Event not found or you do not have permission to edit it."
                ];
                header('Location: events.php');
                exit;
            }
        }

        $_SESSION['event_success'] = "Event updated successfully.";

    // DELETE EVENT
    } elseif ($action === 'delete') {

        $eventId = filter_input(INPUT_POST, 'event_id', FILTER_VALIDATE_INT);

        if (!$eventId || $eventId < 1) {
            $_SESSION['event_errors'] = ["Invalid event selected."];
            header('Location: events.php');
            exit;
        }

        // Delete only if the logged-in user owns the event
        $stmt = $pdo->prepare(
            "DELETE FROM events
             WHERE event_id = ? AND user_id = ?"
        );

        $stmt->execute([$eventId, $userId]);

        if ($stmt->rowCount() > 0) {
            $_SESSION['event_success'] = "Event deleted successfully.";
        } else {
            $_SESSION['event_errors'] = [
                "Event not found or you do not have permission to delete it."
            ];
        }

    } else {
        //shouldnt happen unless someone trys to poke form directly
        $_SESSION['event_errors'] = ["Invalid action requested."];
    }

} catch (PDOException $e) {
    error_log($e->getMessage());

    //technical details need to be logged internally, show generic message to user
    $_SESSION['event_errors'] = [
        "A database error occurred. Please try again."
    ];
}

// Return events page
header('Location: events.php');
exit;

?>